package com.jasmeen.jasmeenAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JasmeenApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(JasmeenApiApplication.class, args);
	}

}
