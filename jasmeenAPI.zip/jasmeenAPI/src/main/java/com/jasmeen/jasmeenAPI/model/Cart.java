package com.jasmeen.jasmeenAPI.model;


import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Cart {
	@Id
	private int prodid;
	private int prodcost;
	private String prodname;
//	private String details;

	public int getProdid() {
		return prodid;
	}
	
	public void setProdid(int prodid) {
		this.prodid= prodid;
	}
	
	public int getProdcost() {
		return prodcost;
	}
	
	public void setProdcost(int prodcost) {
		this.prodcost= prodcost;
	}
	
	public String getProdname() {
		return prodname;
	}
	
	public void setProdname(String prodname) {
		this.prodname= prodname;
	}
	
//	public String getDetails() {
//		return details;
//	}
//	
//	public void setDetails(String details) {
//		this.details= details;
//	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Product name: \n" + prodname + "Product Cost: \n" + prodcost + "Product ID: \n" + prodid + "\n\t" ;
	}
}
