package com.jasmeen.jasmeenAPI.controller;

import org.springframework.web.bind.annotation.RequestMapping;
////import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.RestController;



import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Controller;

import com.jasmeen.jasmeenAPI.repos.ProdRepo;


@Controller
public class HomepageController {
	@Autowired
	ProdRepo repo;
	
	@RequestMapping("/")
	public String Home() {
		return "Home";
	}

}
