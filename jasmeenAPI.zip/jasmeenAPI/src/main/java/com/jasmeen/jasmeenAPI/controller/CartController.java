package com.jasmeen.jasmeenAPI.controller;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.RestController;

import com.jasmeen.jasmeenAPI.model.Cart;
import com.jasmeen.jasmeenAPI.repos.CartRepo;

@Controller
public class CartController {
	@Autowired
	CartRepo repo;
	
	@PostMapping("/cart")
	public String addtoCart(Cart cart) {
		repo.save(cart);
		return "productlist";
	}
	
	@GetMapping("/cart")
//	@ResponseBody
	public String getCart() {
		return "cart";
	}
	
	@DeleteMapping("/cart/{prodid}")
	@ResponseBody
	public String deleteCart1(@PathVariable int prodid) {
		Cart c = repo.getOne(prodid);
		repo.delete(c);
		return "deleted";
	}
	@PostMapping("/cart/{prodid}")
//	@ResponseBody
	public String deleteCart(@PathVariable int prodid) {
		Cart c = repo.getOne(prodid);
		repo.delete(c);
		return "cart";
	}
	@GetMapping("/cart/{prodid}")
	@ResponseBody
	public Optional<Cart> getCart(@PathVariable("prodid") int prodid) {
		return repo.findById(prodid);
	}
}
