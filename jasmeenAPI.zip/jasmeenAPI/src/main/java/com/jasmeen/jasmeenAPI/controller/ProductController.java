package com.jasmeen.jasmeenAPI.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.jasmeen.jasmeenAPI.repos.ProdRepo;
import com.jasmeen.jasmeenAPI.model.Products;

@Controller
public class ProductController {
	@Autowired
	ProdRepo repo;
	
//	@RequestMapping("/")
//	public String Home() {
//		return Home.jsp;
//	}
	
	@GetMapping("/products")
//    @ResponseBody
	public String getProducts() {
		return "productlist";
	}
//	public List<Products> getProducts() {
//		return repo.findAll();
//	}
	
	@RequestMapping("/products/details")
//	@ResponseBody
	public String getAllProductdetails() {
		return "details";
	}
	
//	@RequestMapping("/products/details/{prodid}")
//    @ResponseBody
//	public Optional<Products> getProductdetails(@PathVariable("prodid") int prodid) {
//		return repo.findById(prodid);
//	}
	@RequestMapping("/products/details/{prodid}")
    @ResponseBody
	public ModelAndView getProductdetails(@PathVariable("prodid") int prodid) {
		ModelAndView mv= new ModelAndView();
		mv.addObject("prodid",prodid);
		mv.setViewName("indetails");
		return mv;
	}
	
	
	@RequestMapping("/products/{prodid}")
	@ResponseBody
	public Optional<Products> getProducts(@PathVariable("prodid") int prodid) {
		return repo.findById(prodid);
	}
	
}
