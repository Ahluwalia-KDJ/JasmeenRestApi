package com.jasmeen.jasmeenAPI.repos;
import org.springframework.data.jpa.repository.JpaRepository;
import com.jasmeen.jasmeenAPI.model.Cart;
//import org.springframework.data.annotation.*;


public interface CartRepo extends JpaRepository<Cart, Integer>  
{

}
