package com.jasmeen.jasmeenAPI.repos;

import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.repository.CrudRepository;
import com.jasmeen.jasmeenAPI.model.Products;

public interface ProdRepo extends JpaRepository<Products, Integer> 
{
	
}
